/*    Cours de Traitement d'images
      TP3 - TP Final - Chaîne complète

     Binome: P20
              Ginel DORLEON
              Đào Thúy HồNG

*/

#include <stdio.h>
#include <stdlib.h>
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#define SUM_LEVEL 256

using namespace cv;
using namespace std;

void initHistData(int data[], int N)
{
    for (int i = 0; i < SUM_LEVEL; i++)
      data[i] = 0;
}

void initHistData(float data[], int N)
{
    for (int i = 0; i < SUM_LEVEL; i++)
      data[i] = 0;
}

void initHistData(uchar data[], int N)
{
    for (int i = 0; i < SUM_LEVEL; i++)
      data[i] = 0;
}

void setHistData(Mat src, int data[], int N)
{
    int data_index = 0;
    int img_w = src.cols;
    int img_h = src.rows;
    for(int i = 0; i < img_h; i++)
    for (int j = 0; j < img_w; ++j)
    {
        data_index = src.at<uchar>(i,j);
        data[data_index]++;
    }
}

Scalar getScalar(int chanel)
{
    switch(chanel)
    {
        case 0:
          return Scalar(255, 0, 0);
        case 1:
          return Scalar(0, 255, 0);
        case 2:
          return Scalar(0, 0, 255);
    }
    return  Scalar(255, 0, 0);
}

void drawHist(Mat src, Mat hist, int chanel)
{
    int hist_h = hist.rows/3;
    int data[SUM_LEVEL];
    Scalar scalar;
    Point point_start, point_end;
    initHistData(data, SUM_LEVEL);
    setHistData(src, data, SUM_LEVEL);

    int data_element = 0;
    int max = 0;
    for (int i = 0; i < SUM_LEVEL; ++i)
    {
        data_element = data[i];
        if (max < data_element)
            max = data_element;
    }

    scalar = getScalar(chanel);
    for (int i = 1; i < SUM_LEVEL; i++)
    {
        point_start = Point(i, chanel*hist_h);
        point_end = Point(i, chanel*hist_h - hist_h*data[i]/max);
        line( hist, point_start, point_end, scalar, 2, 8, 0 );
    }
}

int main(int argc, char** argv) {

// 1@Segmetation...................Debut

	Mat img0 = imread(argv[1]); // Cette fonction nous permet de faire la lecture de l'img couleur en entrée
	if (!img0.data) {
		cout << "Attention, il faut donner le nom de l'image\n" << endl;
		return -1;
	}
         else
           cout << " Chaine de traitement en cours d'execution...\n" <<endl;

	Mat img1;
	Mat lab_image;
   	Mat hist(600, 256, CV_8UC3, Scalar(0, 0, 0));
	vector<Mat> rgb_planes;
        split(img0, rgb_planes);
	for (int i = 0; i < 3; i++)
	{
	  drawHist(rgb_planes[i], hist, i + 1);
	}	
	imwrite("hist.jpg", hist);
	
	//Convertir en L*a*b
    	cvtColor(img0, lab_image, CV_BGR2Lab);
    	imwrite("image_lab.jpg", lab_image);

    	// Extraire le channel de L
    	vector<cv::Mat> lab_planes(3);
    	split(lab_image, lab_planes);  //Maintenant nous avons l'image L dans lab_planes[0]

    	//Augmenter le contraste
	//Appliquer CLAHE algorithm pour le channel de L
    	Ptr<CLAHE> clahe = createCLAHE();
    	clahe->setClipLimit(4);
    	Mat _dst;
    	clahe->apply(lab_planes[0], _dst);

    	//Fusionnez les plans de couleur dans une image de L*a*b
    	_dst.copyTo(lab_planes[0]);
    	merge(lab_planes, lab_image);

    	//Convertir en RVB
    	Mat image_clahe;
    	cvtColor(lab_image, image_clahe, CV_Lab2BGR);
    	imwrite("image_clahe.jpg", image_clahe);
    	
    	Mat hist_contrast(600, 256, CV_8UC3, Scalar(0, 0, 0));
	split(image_clahe, rgb_planes);
	for (int i = 0; i < 3; i++)
	{
	  drawHist(rgb_planes[i], hist_contrast, i + 1);
	}	
    	imwrite("hist_contrast.jpg", hist_contrast);

    	cvtColor(image_clahe, img1, CV_BGR2GRAY);
    	imwrite("gray.jpg", img1);

    	int kernel_size = 3;
    	Mat kernel = (Mat_<double>(kernel_size,kernel_size) << 0, -1, 0, -1, 5, -1, 0, -1, 0);

    	/// Appliquer filtre pour rehausser le contour
    	filter2D(img1, img1, -1 , kernel, Point( -1, -1 ), 0, BORDER_DEFAULT );
    	imwrite("rehausseur_contour_0.jpg", img1);
        imshow("rehausseur_contour_0.jpg", img1);

    	//Augmenter le lumiere
    	img1 *= 1.5;

	//Lisser l'image
    	GaussianBlur( img1, img1, Size(5,5), 0, 0, BORDER_DEFAULT );
	imwrite("gaussian_0.jpg", img1);
        imshow( "gaussian_0.jpg", img1);

    	//diminuer les bruits
    	fastNlMeansDenoising(img1, img1, 30.0, 7, 21);
    	imwrite("denoise_0.jpg", img1);
        imshow ( "denoise_0.jpg", img1);

    	filter2D(img1, img1, -1 , kernel, Point( -1, -1 ), 0, BORDER_DEFAULT );
    	imwrite("rehausseur_contour_1.jpg", img1);
        imshow( "rehausseur_contour_1.jpg", img1);

	GaussianBlur( img1, img1, Size(3,3), 0, 0, BORDER_DEFAULT );
	imwrite("gaussian_1.jpg", img1);
        imshow("gaussian_1.jpg", img1);

	//Ici, on va appliquer l'algorithme de OTSU pour etablir le seuil
	threshold(img1, img1, 0, 255, CV_THRESH_BINARY_INV | CV_THRESH_OTSU);

// 1@Segmentation.......................Fin

// ------------------------------------------------------------------------------------------------

// 2@Post-Segmentation...............Debut

// Ajoutdes éléments structurants
	Mat item = getStructuringElement(MORPH_RECT, Size(5, 5));// Size pour la dilatation
	Mat item1 = getStructuringElement(MORPH_RECT, Size(2, 2)); //Size pour l'erosion
	Mat img2;

  //dilatation de limg a l'element structurant avec la fx dilate
	dilate(img1, img2, item);
  // La fonction erode pour l'erosion des imgs et les elements structurants
	erode(img2, img2, item1);


	vector<vector<Point> > contours; // Ce vecteur va permettre de stocker les contours des régions

//Recherche des contours des régions détectées que va contenir l'element vector
	findContours(img2, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);


	Mat check = Mat::zeros(img2.size(), CV_32SC1); // Marquage des régions
	for (size_t i = 0; i < contours.size(); i++)
		drawContours(check, contours, static_cast<int>(i),
				Scalar::all(static_cast<int>(i) + 1), -1);

	//ici@Generation....Aleatoire...de....couleurs
	vector<Vec3b> colors;
	for (size_t i = 0; i < contours.size(); i++) {
		int blue = theRNG().uniform(0, 255);
		int green = theRNG().uniform(0, 255);
		int red = theRNG().uniform(0, 255);
		colors.push_back(Vec3b((uchar) blue, (uchar) green, (uchar) red));
	}

	// Coloration des régions avec des couleurs différentes
	Mat img3 = Mat::zeros(check.size(), CV_8UC3);
	for (int i = 0; i < check.rows; i++)
              {
		for (int j = 0; j < check.cols; j++)
              {
			int index = check.at<int>(i, j);
			if (index > 0 && index <= static_cast<int>(contours.size()))
				img3.at<Vec3b>(i, j) = colors[index - 1];
			else
				img3.at<Vec3b>(i, j) = Vec3b(0, 0, 0);
		}
	}

// Conjonction de l'img entrée et le masque obtenu
	Mat img4;
	img0.copyTo(img4, img3);

//2@Post-Segmentation----------------------Fin

//------------------------------------------------------------------------------------------------------------------

//Affichage des sorties a l'ecran
	
	imwrite("imgSegmOTSU.png", img1);
         imshow("imgSegmOTSU.png", img1);
	
	imwrite("imgPostSegm.png", img3);
        imshow("imgPostSegm.png", img3);

	imshow("imageSegmentee", img4);
	imwrite("imageSegmentee.png", img4);
	waitKey(0);
	return 0;
}

//Fin du programme
