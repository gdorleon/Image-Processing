/*  Cours de Traitement d'images
      TP1  - 2e Partie
      Programme de Calcul du Profil d'Intensité d'une Image  	         	
      Etudiant: Ginel DORLEON - P20- IFI 2016  

    Purpose of this program ?
     
     This program makes it possible to obtain the
     Intensity of an image along a line or a selected column.  																                                     
     How to execute ? 																						////
      In the command line, while in the main directory, type:
       1- cmake
     then       												 		
      2- make
      3- ./LinearFunction following by the image you want to load
																							////
			 
*/

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include <stdio.h>
 
using namespace cv;
using namespace std;
 

//declaratin des fonctions utiles 

Mat IntensityProfil(Mat, int);
Mat histogram (Mat);
Mat FnctionLine (Mat);

// Declaration de notre fonction principale
int main( int argc, char** argv )
{
    Mat second_img;
    
//Lecture de l'image originale i-e , l'image donnee par l'utilisateur
    
    second_img = imread(argv[1], 1 );
      
    if( argc != 2 || !second_img.data )
    {
    cout<<"Image not found \n";
          
      return -1;
    }
  
  namedWindow("Our First Image", 1);
  imshow("Our First Image", second_img);
  
  
 Mat picture3= FnctionLine(second_img);   // ICi, je fait appel a la fonction " FnctionLine (Mat)" declare au debut
 
//Appel de la fonction
 
 Mat picture4=histogram(second_img);
 
 //Nos fenetres d'affichage
 
namedWindow("Histogram from Original Image", CV_WINDOW_AUTOSIZE );
imshow("Histogram from Original Image", picture4 );
  
imwrite("cube.tif", picture4);
  
// 

Mat picture5=histogram(picture3);
namedWindow("Histogram of Contrasted Image", CV_WINDOW_AUTOSIZE );
imshow("Histogram of Contrasted Image", picture5 );
  
imwrite("HistogramContrastedImage.jpg", picture5);




int l = picture3.cols;

Mat third_image = IntensityProfil(picture3,245); // ICi, je fait appel a la fonction " IntensityProfil(Mat, int)" declare au debut
Mat fourth_image = IntensityProfil(second_img,245);

	
	cv::line(picture3,cv::Point(0,245),cv::Point(l,245),cv::Scalar(102,5,100),2,8,0);

	cv::line(second_img,cv::Point(0,245),cv::Point(l,245),cv::Scalar(102,5,100),2,8,0);

	// cv::imwrite

	cv::imwrite("LineForNewImage.png", picture3);
	cv::imwrite("ProfilForNewImage.png", third_image);
	cv::imwrite("LineOrignalImage.png", fourth_image);
	cv::imwrite("IntensityProfil_of_OrignalImage.png", fourth_image);
	cv::imwrite("LineOrignalImage.png", second_img);
	
	cv::imshow("Line_of_NewImage",picture3);
	cv::imshow("ProfilIntensity_NewImage",third_image);
	
	//Affichage des images a l'ecran
	
	cv::imshow("ligne_original_image",second_img);
	cv::imshow("profil_intensite_original_image",fourth_image);

  
 waitKey();
 
}  

//Ici, nous declarons notre fonction principale

Mat FnctionLine(Mat image)
{
 double valc;  
   // Le programme parle a l'utilisater ici
  cout<<" | Ici, vous avez la possibilite de tracer le contraste,l'histograme et |\n | le profil d'intensite en utilisant une fonction lineaire |\n"<<endl;
  cout<<" | Veuilez entrer une valeur pour le contrast |"<<endl;
  cout<<" : "; cin>> valc;
  Mat new_image = Mat::zeros( image.size(), image.type() );

 

for( int y = 0; y < image.rows; y++ )
    { for( int x = 0; x < image.cols; x++ )
         { for( int c = 0; c < 3; c++ )
              {
      new_image.at<Vec3b>(y,x)[c] = saturate_cast<uchar>( valc*( image.at<Vec3b>(y,x)[c] ));
             }
    }
    }
    imshow("image_contrastee", new_image);
    imwrite("image_contrastee.jpg", new_image);

    return new_image;
}



// Cette fonction va permettre de recharger le profil d'intensite

Mat IntensityProfil(Mat image, int row)
{
	cv::Mat sauv (image.rows,image.cols,CV_8UC3,cv::Scalar(0,0,0));
	int cols = image.cols;
	int couleur = image.channels();
	int x;
	x = row;
	
// ICi, en utilisant la boucle if, nous prenons en charge les niveaux de gris et nos 3 principales coulent basiques
	
	if (couleur==3)
	{
		for(int i = 0; i < cols; i++)
		   {
			Vec3b first_Intensity  = image.at<Vec3b>(x, i);
			Vec3b second_Intensity = image.at<Vec3b>(x,i+1);

cv::line(sauv,cv::Point(i,255 - first_Intensity.val[0]),cv::Point(i+1,255 - second_Intensity.val[0]),cv::Scalar(255,0,0),1,8,0); // Blue line
cv::line(sauv,cv::Point(i,255 - first_Intensity.val[1]),cv::Point(i+1,255 - second_Intensity.val[1]),cv::Scalar(0,255,0),1,8,0); // Green Line
cv::line(sauv,cv::Point(i,255 - first_Intensity.val[2]),cv::Point(i+1,255 - second_Intensity.val[2]),cv::Scalar(0,0,255),1,8,0);// Red line 				
 }
}
return sauv;
}



//Ici, nous introduisons la fonction qui nous permet de tracer l'Histogram

Mat histogram( Mat picture1)
{

//Definition des differentes parametres que doit prendre notre histogram
// le size, le range
//Utilisation des couleurs basiqes pour separer notre image

 
  int histSize = 256;  // le nom de la variable est explicite, ici on definit le size de l'histogram
  
  vector<Mat> bgr_planes;
  split( picture1, bgr_planes );

  // Ici, on gere le range aussi, mais cette fois ci pour nos couleurs de base
  bool uniform = true;
  bool accumulate = false;
  Mat histoBlue, histoGreen, histoRed; 
  
 float range[] = { 0, 256 } ; // notre range normalement est compris entre 0 e 256, c logique 
  const float* histRange = { range };

// cadre de notre future histogram
  int largeurHisto = 512; // Oupss, ici on gere la largeur 
  int hauteurHisto = 400; // Et ici, la hauteur (--) 
  int bin_w = cvRound( (double) largeurHisto/histSize );

  Mat drawHistogram( hauteurHisto, largeurHisto, CV_8UC3, Scalar( 0,0,0) ); // cette fonction va ns permettre de dessiner notre histograme

  // Dessiner enfin notre bel histogram (:-) 
  
  calcHist( &bgr_planes[0], 1, 0, Mat(), histoBlue,  1, &histSize, &histRange, uniform, accumulate );
  calcHist( &bgr_planes[1], 1, 0, Mat(), histoGreen, 1, &histSize, &histRange, uniform, accumulate );
  calcHist( &bgr_planes[2], 1, 0, Mat(), histoRed,   1, &histSize, &histRange, uniform, accumulate );

 

  // Normalisation, fonction utilisee depuis le site  http://www.programming-techniques.com/2013/02/calculating-convolution-of-image-with-c_2.html#more
  
  normalize(histoBlue, histoBlue, 0, drawHistogram.rows, NORM_MINMAX, -1, Mat() );
  normalize(histoGreen, histoGreen, 0, drawHistogram.rows, NORM_MINMAX, -1, Mat() );
  normalize(histoRed, histoRed,    0, drawHistogram.rows, NORM_MINMAX, -1, Mat() );

  // Dessiner pour chaque channel
  
  for( int i = 1; i < histSize; i++ )
  {
 line( drawHistogram, Point( bin_w*(i-1), hauteurHisto - cvRound(histoBlue.at<float>(i-1)) ) , Point( bin_w*(i), hauteurHisto - cvRound(histoBlue.at<float>(i)) ),
                       Scalar( 255, 0, 0), 2, 8, 0  );
 line( drawHistogram, Point( bin_w*(i-1), hauteurHisto - cvRound(histoGreen.at<float>(i-1)) ) , Point( bin_w*(i), hauteurHisto - cvRound(histoGreen.at<float>(i)) ),
                       Scalar( 0, 255, 0), 2, 8, 0  );
line( drawHistogram, Point( bin_w*(i-1), hauteurHisto - cvRound(histoRed.at<float>(i-1)) ) , Point( bin_w*(i), hauteurHisto - cvRound(histoRed.at<float>(i)) ),
                       Scalar( 0, 0, 255), 2, 8, 0  );
  }

return drawHistogram; // fonction termine ici
}





