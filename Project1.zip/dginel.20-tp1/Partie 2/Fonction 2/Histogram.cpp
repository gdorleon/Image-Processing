/*  Cours de Traitement d'images
      TP1  - 1ere Partie
      Programme de Calcul du Profil d'Intensité d'une Image  	         	
      Etudiant: Ginel DORLEON - P20- IFI 2016  

    Purpose of this program ?
     
     This program makes it possible to obtain the
     Intensity of an image along a line or a selected column.  																                                     
     How to execute ? 																						////
      In the command line, while in the main directory, type:
First, you should provide the name of the image down where the comment say to : METTRE LE NOM DE L"IMAGE ICI
       1- cmake
     then       												 		
      2- make
      3- ./Histogram
      
																							////
			 
*/

#include<iostream>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>
 
using namespace std;
using namespace cv;
 
int main()
{
    Mat image = imread("ab.png", CV_LOAD_IMAGE_GRAYSCALE); // METTRE LE NOM DE L"IMAGE ICI
 
    // allcoate memory for no of pixels for each intensity value
    int histogram[256];
 
    // Initilaiser toutes les valeurs d'intensite a zero 
     for(int i = 0; i < 255; i++)
    {
        histogram[i] = 0;
    }
 
    // Calculer le nombre de pixel pour chaque valeur du profil d'intensite
    for(int y = 0; y < image.rows; y++)
        for(int x = 0; x < image.cols; x++)
            histogram[(int)image.at<uchar>(y,x)]++;
 
    for(int i = 0; i < 256; i++)
        cout<<histogram[i]<<" ";
 
    // Dessiner l'histogram
    int hist_w = 512; int hist_h = 400;
    int bin_w = cvRound((double) hist_w/256);
 
    Mat histImage(hist_h, hist_w, CV_8UC1, Scalar(255, 255, 255));
 
    // Trouver l'intensite maximum a partir de l'histogram
    int max = histogram[0];
    for(int i = 1; i < 256; i++){
        if(max < histogram[i]){
            max = histogram[i];
        }
    }
 
    // Normalisation de l'histogram entre 0 et la valeur de la colonne de l'histo d l'image.  
    for(int i = 0; i < 255; i++){
        histogram[i] = ((double)histogram[i]/max)*histImage.rows;
    }
 
 
    // Dessiner la ligne d'intensite pour l'histogram    
    for(int i = 0; i < 255; i++)
    {
        line(histImage, Point(bin_w*(i), hist_h),
                              Point(bin_w*(i), hist_h - histogram[i]),
             Scalar(0,0,0), 1, 8, 0);
    }
 
    // Afficher l'histogram
    namedWindow("Intensity Histogram", CV_WINDOW_AUTOSIZE);
    imshow("Image Histogram", histImage);
 
    namedWindow("Image", CV_WINDOW_AUTOSIZE);
    imshow("Image", image);
    imwrite("Histogram.png", histImage);
    waitKey();
    return 0;
}
